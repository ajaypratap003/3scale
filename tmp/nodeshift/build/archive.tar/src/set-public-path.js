import { setPublicPath } from "systemjs-webpack-interop";

setPublicPath("@react-mf/3scale");
